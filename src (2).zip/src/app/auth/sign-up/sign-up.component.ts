import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import User from '../../models/user.model';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-sign-up',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent {

  name: string = '';
  email: string = '';
  password: string = '';
  confirmPassword: string = '';

  errorMsg: string = '';
  successMsg: string = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit() {
    this.errorMsg = '';
    this.successMsg = '';

    // בדיקה בסיסית – סיסמאות זהות
    if (this.password !== this.confirmPassword) {
      this.errorMsg = 'הסיסמאות אינן זהות';
      return;
    }

    const user: Partial<User> = {
      name: this.name,
      email: this.email,
      password: this.password
    };

    this.authService.signUp(user).subscribe({
      next: () => {
        this.successMsg = 'נרשמת בהצלחה! ניתן להתחבר עכשיו';
        // אם את רוצה להעביר ישר ל־sign-in:
        // this.router.navigate(['/sign-in']);
      },
      error: (err: HttpErrorResponse) => {
        if (err.status === 409) {
          this.errorMsg = 'האימייל הזה כבר קיים במערכת';
        } else {
          this.errorMsg = 'שגיאה בהרשמה, נסי שוב מאוחר יותר';
        }
      }
    });
  }
}
