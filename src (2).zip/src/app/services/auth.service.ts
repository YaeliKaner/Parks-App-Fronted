import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import User from '../models/user.model';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private baseUrl = 'http://localhost:8080/api/Users';
  private currentUserKey = 'currentUser';

  constructor(private http: HttpClient) {}

  // SIGN UP
  signUp(user: Partial<User>): Observable<User> {
    return this.http.post<User>(
      `${this.baseUrl}/signUp`,
      user,
      { withCredentials: true }           
    ).pipe(
      tap(u => {
        if (u) {
          localStorage.setItem(this.currentUserKey, JSON.stringify(u));
        }
      })
    );
  }

  // SIGN IN
  // signIn(user: Partial<User>): Observable<User> {
  //   return this.http.post<User>(
  //     `${this.baseUrl}/signIn`,
  //     user,
  //     { withCredentials: true }             
  //   )
  //   .pipe(
  //     tap(u => {
  //       if (u) {
  //         localStorage.setItem(this.currentUserKey, JSON.stringify(u));
  //       }
  //     })
  //   );
  // }

    // SIGN IN
  signIn(user: Partial<User>): Observable<User> {
    return (this.http.post(
      `${this.baseUrl}/signIn`,
      user,
      { 
          withCredentials: true, 
          responseType: 'text'
      }            
    ) as any)
    .pipe(
      tap((u: string) => {
        if (u) {
          localStorage.setItem(this.currentUserKey, u);
        }
      })
    ) as Observable<User>;
  }


  // SIGN OUT – גם לשרת וגם לנקות לוקאל־סטורג'
  signOut(): Observable<any> {
    return this.http.post(
      `${this.baseUrl}/signOut`,
      {},
      { withCredentials: true, responseType: 'text' }  
    ).pipe(
      tap(() => {
        localStorage.removeItem(this.currentUserKey);
      })
    );
  }

  getCurrentUser(): User | null {
    const json = localStorage.getItem(this.currentUserKey);
    return json ? JSON.parse(json) as User : null;
  }

  isLoggedIn(): boolean {
    return this.getCurrentUser() !== null;
  }
}
