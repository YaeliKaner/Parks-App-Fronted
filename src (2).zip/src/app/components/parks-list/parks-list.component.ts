import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { ParksService } from '../../services/parks.service';
import ParkDTO from '../../models/dto/parkDTO.model';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-parks-list',
  imports: [RouterModule],
  templateUrl: './parks-list.component.html',
  styleUrl: './parks-list.component.css'
})
export class ParksListComponent implements OnInit {

  public parksList: ParkDTO[] = [];

  constructor(
    private router: Router,
    private _parksService: ParksService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this._parksService.getParks().subscribe({
      next: (res) => {
        this.parksList = res;
      },
      error: (err) => {
        console.log(err);
      }
    });
  }

  onSignOut() {
    this.authService.signOut().subscribe({
      next: () => this.router.navigate(['/sign-in']),
      error: () => alert('שגיאה בהתנתקות')
    });
  }
}
