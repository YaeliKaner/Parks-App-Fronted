
import { Routes } from '@angular/router';
import { ParksListComponent } from './components/parks-list/parks-list.component';
import { AddParkComponent } from './components/add-park/add-park.component';
import { SignInComponent } from './auth/sign-in/sign-in.component';
import { SignUpComponent } from './auth/sign-up/sign-up.component';

export const routes: Routes = [
  { path: '', redirectTo: 'sign-in', pathMatch: 'full' },

  { path: 'sign-in', component: SignInComponent },
  { path: 'sign-up', component: SignUpComponent },

  { path: 'add-park', component: AddParkComponent },
  { path: 'parks-list', component: ParksListComponent }
];

